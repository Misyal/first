﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem.pesonFunction
{
    public partial class PersonLeave : Form
    {
        string ID;
        public PersonLeave(string ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void Btleave_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("请输入姓名！");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("请输入时间！");
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("请输入理由！");
            }
            else
            {               
                string sqlInsert = "insert into EmployeeLeave values('" + ID+ "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" +"未批准" +"')";
                Sqlserver.ExecuteNonQuery(sqlInsert);
                MessageBox.Show("请假申请成功！");
                
            }
        }

        private void Btcancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
