﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem.pesonFunction
{
    public partial class UpdatePwd : Form
    {
        string ID;
        string PWD;
        public UpdatePwd(string ID,string PWD)
        {
            this.ID = ID;
            this.PWD = PWD;
            InitializeComponent();
        }

        private void Btupdate_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("请输入旧密码！");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("请输入新密码！");
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("请确认新密码！");
            }
            else if (textBox1.Text==PWD )
            {
                if (textBox2.Text == textBox3.Text)
                {
                    string sqlUpdate = "update  Employee set employeePwd='" + textBox3.Text + "'"+"where employeeId='"+ID+"'";
                    Sqlserver.ExecuteNonQuery(sqlUpdate);
                    MessageBox.Show("修改密码成功！");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("两次密码不一致！");
                }
                
            }
            else
            {
                MessageBox.Show("旧密码错误!");
               
            }
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Function2 function = new Function2(ID, PWD);
            this.Hide();
            function.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
