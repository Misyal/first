﻿namespace PersonManageSystem
{
    partial class Login
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.quit = new System.Windows.Forms.Button();
            this.btlogin = new System.Windows.Forms.Button();
            this.textUserName = new System.Windows.Forms.TextBox();
            this.textUserPwd = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("华文新魏", 12F);
            this.label1.Location = new System.Drawing.Point(129, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "登录名：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("华文新魏", 12F);
            this.label2.Location = new System.Drawing.Point(138, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "密码：";
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.Transparent;
            this.quit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quit.Font = new System.Drawing.Font("华文新魏", 11F);
            this.quit.Location = new System.Drawing.Point(264, 176);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(87, 25);
            this.quit.TabIndex = 3;
            this.quit.Text = "取消";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // btlogin
            // 
            this.btlogin.BackColor = System.Drawing.Color.Transparent;
            this.btlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btlogin.Font = new System.Drawing.Font("华文新魏", 11F);
            this.btlogin.Location = new System.Drawing.Point(132, 176);
            this.btlogin.Name = "btlogin";
            this.btlogin.Size = new System.Drawing.Size(87, 25);
            this.btlogin.TabIndex = 1;
            this.btlogin.Text = "登录";
            this.btlogin.UseVisualStyleBackColor = false;
            this.btlogin.Click += new System.EventHandler(this.btlogin_Click);
            // 
            // textUserName
            // 
            this.textUserName.Location = new System.Drawing.Point(200, 42);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(130, 21);
            this.textUserName.TabIndex = 0;
            // 
            // textUserPwd
            // 
            this.textUserPwd.Location = new System.Drawing.Point(200, 113);
            this.textUserPwd.Name = "textUserPwd";
            this.textUserPwd.Size = new System.Drawing.Size(130, 21);
            this.textUserPwd.TabIndex = 1;
            this.textUserPwd.UseSystemPasswordChar = true;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(455, 247);
            this.Controls.Add(this.textUserPwd);
            this.Controls.Add(this.textUserName);
            this.Controls.Add(this.btlogin);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MaximizeBox = false;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "登录";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Button btlogin;
        private System.Windows.Forms.TextBox textUserName;
        private System.Windows.Forms.TextBox textUserPwd;
    }
}

