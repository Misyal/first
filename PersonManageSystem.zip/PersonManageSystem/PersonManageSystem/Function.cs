﻿using PersonManageSystem.departManage;
using PersonManageSystem.leaveManage;
using PersonManageSystem.salaryManage;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem
{
    public partial class Function : Form
    {
        public Function()
        {
            InitializeComponent();
        }


        //private void personManage_Click_1(object sender, EventArgs e)
        //{
        //    PersonManage personManage = new PersonManage();
        //    personManage.ShowDialog();
        //}

        //private void salaryManage_Click(object sender, EventArgs e)
        //{
        //    SalaryManage salaryManage = new SalaryManage();
        //    salaryManage.ShowDialog();
                

        //}

        //private void departManage_Click(object sender, EventArgs e)
        //{
        //    DepartManage departManage = new DepartManage();
        //    departManage.ShowDialog();
        //}

        //private void leaveManage_Click(object sender, EventArgs e)
        //{
        //    LeaveManage leaveManage = new LeaveManage();
        //    leaveManage.ShowDialog();
        //}

        private void 返回上一级ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog();           
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 员工管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PersonManage personManage = new PersonManage();
            this.Hide();
            personManage.ShowDialog();               
        }

        private void 部门管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DepartManage departManage = new DepartManage();
            this.Hide();
            departManage.ShowDialog();
        }

        private void 薪资管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalaryManage salaryManage = new SalaryManage();
            this.Hide();
            salaryManage.ShowDialog();
        }

        private void 请假管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LeaveManage leaveManage = new LeaveManage();
            this.Hide();
            leaveManage.ShowDialog();
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("软件最终解释权归刘子琦，刘孟恺所有。");
        }

        private void 友情链接ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://172.22.128.44:8088");
        }
    }
}