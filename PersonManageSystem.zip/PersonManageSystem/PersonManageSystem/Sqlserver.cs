﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonManageSystem
{
    class Sqlserver
    {   //连接数据库
        public static string connectionString = "Data Source=KIKU;Initial Catalog=PersonManagement;Persist Security Info=True;User ID=sa;Password=123456";              
        public static SqlConnection getConection()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            return con;
        }
        
        //运行sql语句方法
        public static int ExecuteNonQuery(string strsql)
        {
            SqlConnection con = getConection();
            SqlCommand cmd = new SqlCommand(strsql,con);
            //cmd.CommandText = strsql;
            //cmd.Connection = con;
            return cmd.ExecuteNonQuery();                        
        }


        //另一个查询方式，主要是员工请假使用
        public static int ExecuteNonQuery2(string strsql)
        {
            SqlConnection con = getConection();
            SqlCommand cmd = new SqlCommand(strsql, con);         
            SqlDataReader myReader = cmd.ExecuteReader();
            if (!myReader.Read())
                return -1;
            else if (myReader.GetValue(0).Equals("未批准"))
            {
                return 0;

            }
            else
                return 1;
                             
        }

        //返回myReader，
        public static SqlDataReader ExecuteDataReader(string strsql)
        {
            SqlConnection con = getConection();
            SqlCommand cmd = new SqlCommand(strsql, con);         
                try
                {
                    return cmd.ExecuteReader();
                }
                catch (SqlException e)
                {
                    con.Close();
                    throw e;
                }
         }
         //返回查询到的第一行的第一列                    
        public static object ExecuteScalar(string strsql)
        {
            SqlConnection con = getConection();
            SqlCommand cmd = new SqlCommand(strsql, con);
            return cmd.ExecuteScalar();                         
        }

        public static DataSet DataShow(string sqlSelect)
        {
            string connectionString = "Data Source=KIKU;Initial Catalog=PersonManagement;Persist Security Info=True;User ID=sa;Password=123456";
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter(sqlSelect, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Employee");
            return ds;
           
        }
    }
} 
