﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem
{
    public partial class EmployeeUpdate : Form
    {
        int employeeId;
        string employeeName;
        string employeePwd;
        string employeeMail;
        string employeePhone;
        string employeeSalary;
        string departmentName;
        public EmployeeUpdate(int Id,string employeeName, string employeePwd, string employeeMail, string employeePhone, string  employeeSalary, string  departmentName)
        {
            InitializeComponent();
            employeeId = Id;
            textId.Text = employeeId.ToString();
            textName.Text = employeeName;
            textPwd.Text = employeePwd;
            textMail.Text = employeeMail;
            textPhone.Text= employeePhone;
            textSalary.Text = employeeSalary;
            textDepart.Text = departmentName;

        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdatePerson_Click(object sender, EventArgs e)
        {
            if (textId.Text == "")
            {
                label1.Text = "*编号必填*";
                label1.ForeColor = Color.Red;
            }
            else if (textName.Text == "")
            {
                label2.Text = "*姓名必填*";
                label2.ForeColor = Color.Red;
            }
            else if (textPwd.Text == "")
            {
                label3.Text = "*密码必填*";
                label3.ForeColor = Color.Red;
            }

            else if (textMail.Text == "")
            {
                label4.Text = "*邮箱必填*";
                label4.ForeColor = Color.Red;
            }
            else if (textPhone.Text == "")
            {
                label5.Text = "*电话必填*";
                label5.ForeColor = Color.Red;
            }
            else if (textSalary.Text == "")
            {
                label6.Text = "*薪资必填*";
                label6.ForeColor = Color.Red;

            }
            else if (Convert.ToInt16(textSalary.Text) < 0)
            {
                label6.Text = "*薪资不能小于0*";
                label6.ForeColor = Color.Red;
            }
            else if (textDepart.Text == "")
            {
                label7.Text = "*部门必填*";
                label7.ForeColor = Color.Red;
            }
            else
            {
                String strSelect = "select departmentId from Department where departmentName ='" + textDepart.Text + "'";
                int departmentId = (Int32)Sqlserver.ExecuteScalar(strSelect);
                
                string sqlUpdate = "update Employee set employeeId='" + int.Parse(textId.Text) + "',employeeName='" + textName.Text + "',employeePwd='" + textPwd.Text + "',employeeEmail='" + textMail.Text + "',employeePhone='" + textPhone.Text + "',employeeSalary='" + int.Parse(textSalary.Text) + "',departmentId='" + departmentId + "'where employeeId='"+employeeId+"'";
                Sqlserver.ExecuteNonQuery(sqlUpdate);
                MessageBox.Show("修改成功");
                this.Close();
            }
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
