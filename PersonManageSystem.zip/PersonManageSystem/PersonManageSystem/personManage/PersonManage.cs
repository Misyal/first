﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PersonManageSystem
{
    public partial class PersonManage : Form
    {
        public PersonManage()
        {
            InitializeComponent();
        }

        //显示信息方法
        public void DataDisplay(string sqlSelect)
        {                      
            employeeGrid.DataSource = Sqlserver.DataShow(sqlSelect).Tables["Employee"];
        }


        //显示全部员工信息
        private void 显示全部_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select * from perdep";            
            DataDisplay(sqlSelect);
        }

        //查询员工信息
        private void 查询_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select * from perdep where 1=1";
            string text = textId.Text.Trim();
            if (text == "")
            {
                MessageBox.Show("请输入工号！");
            }
            else 
            {
                sqlSelect += "and 员工编号 ="+text;
                DataDisplay(sqlSelect);
            }
            
        }

        private void 添加_Click(object sender, EventArgs e)
        {
            EmployeeAdd employeeAdd = new EmployeeAdd();
            employeeAdd.ShowDialog();


        }

        private void delPerson_Click(object sender, EventArgs e)
        {
            //DialogResult DRS = MessageBox.Show("确定要删除选中行数据码？", "提示", MessageBoxButtons.YesNo);
            int employeeId = Convert.ToInt32(employeeGrid.SelectedRows[0].Cells["员工编号"].Value.ToString());
            string sqlDel = "delete Employee where employeeId='"+employeeId+"'";
            Sqlserver.ExecuteNonQuery(sqlDel);
            DataDisplay("select * from Employee");
        }

        private void Update_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(employeeGrid.SelectedRows[0].Cells["员工编号"].Value.ToString());
            string  employeeName = employeeGrid.SelectedRows[0].Cells["员工姓名"].Value.ToString();
            string employeePwd = employeeGrid.SelectedRows[0].Cells["密码"].Value.ToString();
            string employeeMail = employeeGrid.SelectedRows[0].Cells["邮箱"].Value.ToString();
            string employeePhone = employeeGrid.SelectedRows[0].Cells["电话"].Value.ToString();
            string employeeSalary = employeeGrid.SelectedRows[0].Cells["薪资"].Value.ToString();
            string departmentName = employeeGrid.SelectedRows[0].Cells["部门名称"].Value.ToString();
            EmployeeUpdate employeeUpdate = new EmployeeUpdate(employeeId,employeeName,employeePwd,employeeMail,employeePhone,employeeSalary,departmentName);
            employeeUpdate.ShowDialog();

        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Function function = new Function();
            this.Hide();
            function.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}