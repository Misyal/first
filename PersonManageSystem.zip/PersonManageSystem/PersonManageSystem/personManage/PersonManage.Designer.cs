﻿namespace PersonManageSystem
{
    partial class PersonManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonManage));
            this.添加 = new System.Windows.Forms.Button();
            this.delPerson = new System.Windows.Forms.Button();
            this.查询 = new System.Windows.Forms.Button();
            this.Update = new System.Windows.Forms.Button();
            this.employeeGrid = new System.Windows.Forms.DataGridView();
            this.personManagementDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.textId = new System.Windows.Forms.TextBox();
            this.显示全部 = new System.Windows.Forms.Button();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.返回ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.employeeGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // 添加
            // 
            this.添加.BackColor = System.Drawing.Color.Transparent;
            this.添加.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.添加.Font = new System.Drawing.Font("华文新魏", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.添加.Location = new System.Drawing.Point(186, 353);
            this.添加.Name = "添加";
            this.添加.Size = new System.Drawing.Size(87, 23);
            this.添加.TabIndex = 0;
            this.添加.Text = "添加员工";
            this.添加.UseVisualStyleBackColor = false;
            this.添加.Click += new System.EventHandler(this.添加_Click);
            // 
            // delPerson
            // 
            this.delPerson.BackColor = System.Drawing.Color.Transparent;
            this.delPerson.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delPerson.Font = new System.Drawing.Font("华文新魏", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delPerson.Location = new System.Drawing.Point(333, 353);
            this.delPerson.Name = "delPerson";
            this.delPerson.Size = new System.Drawing.Size(87, 23);
            this.delPerson.TabIndex = 0;
            this.delPerson.Text = "删除员工";
            this.delPerson.UseVisualStyleBackColor = false;
            this.delPerson.Click += new System.EventHandler(this.delPerson_Click);
            // 
            // 查询
            // 
            this.查询.BackColor = System.Drawing.Color.Transparent;
            this.查询.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.查询.Font = new System.Drawing.Font("华文新魏", 11F);
            this.查询.Location = new System.Drawing.Point(419, 23);
            this.查询.Name = "查询";
            this.查询.Size = new System.Drawing.Size(55, 32);
            this.查询.TabIndex = 0;
            this.查询.Text = "查询";
            this.查询.UseVisualStyleBackColor = false;
            this.查询.Click += new System.EventHandler(this.查询_Click);
            // 
            // Update
            // 
            this.Update.BackColor = System.Drawing.Color.Transparent;
            this.Update.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Update.Font = new System.Drawing.Font("华文新魏", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Update.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Update.Location = new System.Drawing.Point(491, 353);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(86, 23);
            this.Update.TabIndex = 0;
            this.Update.Text = "修改员工";
            this.Update.UseVisualStyleBackColor = false;
            this.Update.Click += new System.EventHandler(this.Update_Click);
            // 
            // employeeGrid
            // 
            this.employeeGrid.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.employeeGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeGrid.Location = new System.Drawing.Point(-6, 76);
            this.employeeGrid.Name = "employeeGrid";
            this.employeeGrid.RowHeadersWidth = 51;
            this.employeeGrid.RowTemplate.Height = 23;
            this.employeeGrid.Size = new System.Drawing.Size(757, 262);
            this.employeeGrid.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("华文新魏", 12F);
            this.label1.Location = new System.Drawing.Point(169, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "工号：";
            // 
            // textId
            // 
            this.textId.Location = new System.Drawing.Point(231, 30);
            this.textId.Name = "textId";
            this.textId.Size = new System.Drawing.Size(174, 21);
            this.textId.TabIndex = 3;
            // 
            // 显示全部
            // 
            this.显示全部.BackColor = System.Drawing.Color.Transparent;
            this.显示全部.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.显示全部.Font = new System.Drawing.Font("华文新魏", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.显示全部.Location = new System.Drawing.Point(491, 23);
            this.显示全部.Name = "显示全部";
            this.显示全部.Size = new System.Drawing.Size(92, 32);
            this.显示全部.TabIndex = 4;
            this.显示全部.Text = "显示全部";
            this.显示全部.UseVisualStyleBackColor = false;
            this.显示全部.Click += new System.EventHandler(this.显示全部_Click);
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataSource = this.personManagementDataSetBindingSource;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(747, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.返回ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.系统ToolStripMenuItem.Text = "系统";
            // 
            // 返回ToolStripMenuItem
            // 
            this.返回ToolStripMenuItem.Name = "返回ToolStripMenuItem";
            this.返回ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.返回ToolStripMenuItem.Text = "返回";
            this.返回ToolStripMenuItem.Click += new System.EventHandler(this.返回ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // PersonManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(747, 422);
            this.Controls.Add(this.显示全部);
            this.Controls.Add(this.textId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.employeeGrid);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.查询);
            this.Controls.Add(this.delPerson);
            this.Controls.Add(this.添加);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimizeBox = false;
            this.Name = "PersonManage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "员工管理";
            ((System.ComponentModel.ISupportInitialize)(this.employeeGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button 添加;
        private System.Windows.Forms.Button delPerson;
        private System.Windows.Forms.Button 查询;
        private System.Windows.Forms.Button Update;
        private System.Windows.Forms.DataGridView employeeGrid;
        private System.Windows.Forms.BindingSource personManagementDataSetBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textId;
        private System.Windows.Forms.Button 显示全部;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private PersonManagementDataSet personManagementDataSet;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 返回ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
    }
}