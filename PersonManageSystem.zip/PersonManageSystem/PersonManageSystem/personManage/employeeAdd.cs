﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem
{
    public partial class EmployeeAdd : Form
    {
        public EmployeeAdd()
        {
            InitializeComponent();
        }

        private void AddPerson_Click(object sender, EventArgs e)
        {
            
            if (textId.Text == "")
            {
                label1.Text = "*必填";
            }
            else if (textName.Text == "")
            {
                label2.Text = "*必填";
            }
            else if (textPwd.Text == "")
            {
                label3.Text = "*必填";
            }
            
            else if (textMail.Text == "")
            {
                label4.Text = "*必填";
            }
            else if (textPhone.Text == "")
            {
                label5.Text = "*必填";
            }
            else if (textSalary.Text == "")
            {
                label6.Text = "必填";
                
            }
            else if (Convert.ToInt16(textSalary.Text) < 0)
            {
                label6.Text = "不能小于0";
            }
            else if (textDepart.Text == "")
            {
                label7.Text = "*必填";
            }
            else
            {
                String strSelect = "select departmentId from Department where departmentName ='" + textDepart.Text + "'";
                int departmentId = (Int32)Sqlserver.ExecuteScalar(strSelect);
                string sqlInsert = "insert into Employee values('" + textId.Text + "','" + textName.Text + "','" + textPwd.Text + "','" + textMail.Text + "','" + textPhone.Text + "','" + Convert.ToInt16(textSalary.Text) + "','" + departmentId + "')";
                Sqlserver.ExecuteNonQuery(sqlInsert);
                MessageBox.Show("添加成功");
                this.Close();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
