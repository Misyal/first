﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem.departManage
{
    public partial class DepartManage : Form
    {
        public DepartManage()
        {
            InitializeComponent();
        }
        public void DataDisplay(string sqlSelect)
        {
           
            departGridView.DataSource = Sqlserver.DataShow(sqlSelect).Tables["Employee"];
        }

        private void departSearch_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select employeeId 员工编号,employeeName 员工姓名,departmentName 部门名称 from personDepart  where departmentName='";
            string text = comboxDepart.Text;
            if (text == ("部门总览"))
            {
                string sqlSelectAll = "select departmentId 部门编号,departmentName 部门名称 from Department";
                DataDisplay(sqlSelectAll);
            }
            if (text == ("人事部"))
            {
                sqlSelect += text+"'";
                DataDisplay(sqlSelect);
                name.Text = text;
                int num = departGridView.RowCount-1;
                number.Text = num.ToString();
            }
            else if (text == "财务部")
            {
                sqlSelect += text + "'";
                DataDisplay(sqlSelect);
                name.Text = text;
                int num = departGridView.RowCount-1;
                number.Text = num.ToString();
            }
            else if (text == "营销部")
            {
                sqlSelect += text + "'";
                DataDisplay(sqlSelect);
                name.Text = text;
                int num = departGridView.RowCount-1;
                number.Text = num.ToString();
            }
            else if (text == "技术部")
            {
                sqlSelect += text + "'";
                DataDisplay(sqlSelect);
                name.Text = text;
                int num = departGridView.RowCount-1;
                number.Text = num.ToString();
            }
            else if (text == "行政部")
            {
                sqlSelect += text + "'";
                DataDisplay(sqlSelect);
                name.Text = text;
                int num = departGridView.RowCount-1;
                number.Text = num.ToString();
            }
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Function function = new Function();
            this.Hide();
            function.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
