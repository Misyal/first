﻿namespace PersonManageSystem
{
    partial class Function2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Function2));
            this.personMessage = new System.Windows.Forms.Button();
            this.leave = new System.Windows.Forms.Button();
            this.personGridView = new System.Windows.Forms.DataGridView();
            this.UpdatePwd = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.返回ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.personGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // personMessage
            // 
            this.personMessage.BackColor = System.Drawing.Color.Transparent;
            this.personMessage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.personMessage.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.personMessage.Location = new System.Drawing.Point(159, 33);
            this.personMessage.Name = "personMessage";
            this.personMessage.Size = new System.Drawing.Size(75, 23);
            this.personMessage.TabIndex = 0;
            this.personMessage.Text = "个人信息";
            this.personMessage.UseVisualStyleBackColor = false;
            this.personMessage.Click += new System.EventHandler(this.personMessage_Click);
            // 
            // leave
            // 
            this.leave.BackColor = System.Drawing.Color.Transparent;
            this.leave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.leave.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.leave.Location = new System.Drawing.Point(253, 33);
            this.leave.Name = "leave";
            this.leave.Size = new System.Drawing.Size(75, 23);
            this.leave.TabIndex = 0;
            this.leave.Text = "请假";
            this.leave.UseVisualStyleBackColor = false;
            this.leave.Click += new System.EventHandler(this.leave_Click);
            // 
            // personGridView
            // 
            this.personGridView.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.personGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.personGridView.Location = new System.Drawing.Point(40, 79);
            this.personGridView.Name = "personGridView";
            this.personGridView.RowTemplate.Height = 23;
            this.personGridView.Size = new System.Drawing.Size(528, 64);
            this.personGridView.TabIndex = 0;
            // 
            // UpdatePwd
            // 
            this.UpdatePwd.BackColor = System.Drawing.Color.Transparent;
            this.UpdatePwd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UpdatePwd.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UpdatePwd.Location = new System.Drawing.Point(350, 33);
            this.UpdatePwd.Name = "UpdatePwd";
            this.UpdatePwd.Size = new System.Drawing.Size(75, 23);
            this.UpdatePwd.TabIndex = 0;
            this.UpdatePwd.TabStop = false;
            this.UpdatePwd.Text = "修改密码";
            this.UpdatePwd.UseVisualStyleBackColor = false;
            this.UpdatePwd.Click += new System.EventHandler(this.UpdatePwd_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(596, 25);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.返回ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.系统ToolStripMenuItem.Text = "系统";
            // 
            // 返回ToolStripMenuItem
            // 
            this.返回ToolStripMenuItem.Name = "返回ToolStripMenuItem";
            this.返回ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.返回ToolStripMenuItem.Text = "返回";
            this.返回ToolStripMenuItem.Click += new System.EventHandler(this.返回ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // Function2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(596, 156);
            this.Controls.Add(this.UpdatePwd);
            this.Controls.Add(this.personGridView);
            this.Controls.Add(this.leave);
            this.Controls.Add(this.personMessage);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Function2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "员工界面";
            ((System.ComponentModel.ISupportInitialize)(this.personGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button personMessage;
        private System.Windows.Forms.Button leave;
        private System.Windows.Forms.DataGridView personGridView;
        private System.Windows.Forms.Button UpdatePwd;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 返回ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
    }
}