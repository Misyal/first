﻿using PersonManageSystem.pesonFunction;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem
{
    public partial class Function2 : Form
    {
        string ID;
        string PWD;
        public Function2(string ID,string PWD)
        {
            this.ID = ID;
            this.PWD = PWD;
            InitializeComponent();
        }
        public Function2() {
            InitializeComponent();
        }

        public void DataDisplay(string sqlSelect)
        {            
            personGridView.DataSource = Sqlserver.DataShow(sqlSelect).Tables["Employee"];
        }

        private void personMessage_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select * from perdep where 员工编号='"+ID+"'";
            DataDisplay(sqlSelect);
        }

        private void leave_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select isApply from EmployeeLeave where employeeId = " + ID;
            int x = Sqlserver.ExecuteNonQuery2(sqlSelect);
            if (x == -1)
            {
                PersonLeave personLeave = new PersonLeave(ID);               
                personLeave.ShowDialog();

            }
            else if (x == 0)
            {
                MessageBox.Show("已提交申请，未批准");

            }
            else {
                MessageBox.Show("已提交申请，已批准");

            }
            
        }

        private void UpdatePwd_Click(object sender, EventArgs e)
        {
            UpdatePwd updatePwd = new UpdatePwd(ID, PWD);
            updatePwd.ShowDialog();

        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
