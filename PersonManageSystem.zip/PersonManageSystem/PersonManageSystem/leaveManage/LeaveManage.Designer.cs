﻿namespace PersonManageSystem.leaveManage
{
    partial class LeaveManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LeaveManage));
            this.LookApply = new System.Windows.Forms.Button();
            this.allow = new System.Windows.Forms.Button();
            this.leaveGridView = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.返回ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.delLeave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.leaveGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LookApply
            // 
            this.LookApply.BackColor = System.Drawing.Color.Transparent;
            this.LookApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LookApply.Font = new System.Drawing.Font("华文新魏", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LookApply.Location = new System.Drawing.Point(123, 91);
            this.LookApply.Name = "LookApply";
            this.LookApply.Size = new System.Drawing.Size(93, 33);
            this.LookApply.TabIndex = 0;
            this.LookApply.Text = "查看申请";
            this.LookApply.UseVisualStyleBackColor = false;
            this.LookApply.Click += new System.EventHandler(this.LookApply_Click);
            // 
            // allow
            // 
            this.allow.BackColor = System.Drawing.Color.Transparent;
            this.allow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.allow.Font = new System.Drawing.Font("华文新魏", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.allow.Location = new System.Drawing.Point(255, 91);
            this.allow.Name = "allow";
            this.allow.Size = new System.Drawing.Size(75, 33);
            this.allow.TabIndex = 0;
            this.allow.Text = "批准";
            this.allow.UseVisualStyleBackColor = false;
            this.allow.Click += new System.EventHandler(this.allow_Click);
            // 
            // leaveGridView
            // 
            this.leaveGridView.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.leaveGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.leaveGridView.GridColor = System.Drawing.SystemColors.Control;
            this.leaveGridView.Location = new System.Drawing.Point(5, 159);
            this.leaveGridView.Name = "leaveGridView";
            this.leaveGridView.RowTemplate.Height = 23;
            this.leaveGridView.Size = new System.Drawing.Size(548, 177);
            this.leaveGridView.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(559, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.返回ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.系统ToolStripMenuItem.Text = "系统";
            // 
            // 返回ToolStripMenuItem
            // 
            this.返回ToolStripMenuItem.Name = "返回ToolStripMenuItem";
            this.返回ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.返回ToolStripMenuItem.Text = "返回";
            this.返回ToolStripMenuItem.Click += new System.EventHandler(this.返回ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // delLeave
            // 
            this.delLeave.BackColor = System.Drawing.Color.Transparent;
            this.delLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delLeave.Font = new System.Drawing.Font("华文新魏", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delLeave.Location = new System.Drawing.Point(368, 91);
            this.delLeave.Name = "delLeave";
            this.delLeave.Size = new System.Drawing.Size(75, 33);
            this.delLeave.TabIndex = 3;
            this.delLeave.Text = "删除";
            this.delLeave.UseVisualStyleBackColor = false;
            this.delLeave.Click += new System.EventHandler(this.delLeave_Click);
            // 
            // LeaveManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(559, 335);
            this.Controls.Add(this.delLeave);
            this.Controls.Add(this.leaveGridView);
            this.Controls.Add(this.allow);
            this.Controls.Add(this.LookApply);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "LeaveManage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "请假管理";
            ((System.ComponentModel.ISupportInitialize)(this.leaveGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button LookApply;
        private System.Windows.Forms.Button allow;
        private System.Windows.Forms.DataGridView leaveGridView;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 返回ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.Button delLeave;
    }
}