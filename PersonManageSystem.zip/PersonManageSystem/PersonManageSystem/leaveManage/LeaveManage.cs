﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem.leaveManage
{
    public partial class LeaveManage : Form
    {
        public LeaveManage()
        {
            InitializeComponent();
        }

        public void DataDisplay(string sqlSelect)
        {           
            leaveGridView.DataSource = Sqlserver.DataShow(sqlSelect).Tables["Employee"];
        }
        private void LookApply_Click(object sender, EventArgs e)
        {
            string sqlselect = "select employeeId 员工编号, employeeName 员工姓名,Time 申请时间, reason 请假理由,IsApply 批准状态 from EmployeeLeave";
            DataDisplay(sqlselect);
        }

        private void allow_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(leaveGridView.SelectedRows[0].Cells["员工编号"].Value.ToString());
            string sqlUpdate = "update EmployeeLeave set IsApply= '"+"已批准"+"'"+"where employeeId='"+employeeId+"'";
            Sqlserver.ExecuteNonQuery(sqlUpdate);
            DataDisplay("select * from EmployeeLeave");
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Function function = new Function();            
            this.Hide();           
            function.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void delLeave_Click(object sender, EventArgs e)
        {
            int employeeId = Convert.ToInt32(leaveGridView.SelectedRows[0].Cells["员工编号"].Value.ToString());
            string sqlDelete = "delete EmployeeLeave where employeeId='" + employeeId + "'";
            Sqlserver.ExecuteNonQuery(sqlDelete);
            
        }
    }
}
