﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem
{
    public partial class Login : System.Windows.Forms.Form
    {
        public string UserName;
        public string UserPassword;       
        public Login()
        {
            
            InitializeComponent();
           
        }

        private void btlogin_Click(object sender, EventArgs e)
        {
            
            if (textUserName.Text.Trim() == "" || textUserPwd.Text.Trim() == "")
            {
                //弹出消息提示登录失败
                MessageBox.Show("登录名或密码不能为空！");                       
                //定位光标
                textUserName.Focus();
            }
            else
            {
                
                UserName = textUserName.Text;
                UserPassword= textUserPwd.Text;
                //登录代码
                int flag;
                try
                {
                    //定义sql查询语句
                    string sqlSelect = string.Format("select * from Employee where employeeId = '{0}' and employeePwd = '{1}'and departmentId = (select departmentId from Department where departmentName = '人事部')", UserName, UserPassword);
                    string sqlSelect2 = string.Format("select * from Employee where employeeId = '{0}' and employeePwd = '{1}'and departmentId != 1", UserName, UserPassword);
                    //提交sql查询语句，返回SqlDataReader的对象
                    SqlDataReader myReader = Sqlserver.ExecuteDataReader(sqlSelect);
                    SqlDataReader myReader2 = Sqlserver.ExecuteDataReader(sqlSelect2);
                    //判断myReader是否有行数据,确定是否可以登录
                    if (myReader.HasRows)
                    {
                        flag = 1;
                        //关闭数据阅读器
                        myReader.Close();
                    }
                    else if (myReader2.HasRows) 
                    {
                        flag = 2;
                        myReader2.Close();
                    }
                    else
                    {
                        flag=0;
                    }

                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message.ToString());
                    flag=0;
                }
                
                if (flag == 1)
                    {
                   //进入登录之后的界面
                   //创建窗体对象
                   Function function = new Function();
                   //隐藏登录窗体
                   this.Hide();
                   //打开功能窗体
                   function.ShowDialog();
                   //关闭窗体
                   

                 }
                else if (flag ==2)
                {
                    string ID = textUserName.Text;
                    string PWD = textUserPwd.Text;
                    Function2 function = new Function2(ID,PWD);
                    this.Hide();
                    function.ShowDialog();
                    this.Close();
                }
                else
                 {
                 //弹出消息提示
                 MessageBox.Show("您不是管理员或登录名、密码有误！");
                 textUserPwd.Clear();
                 //定位光标
                 textUserPwd.Focus();
                 }              
            }
                
        }

        private void quit_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

       
    }

       
 }

