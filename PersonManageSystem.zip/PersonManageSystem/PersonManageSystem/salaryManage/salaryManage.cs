﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonManageSystem.salaryManage
{
    public partial class SalaryManage : Form
    {
        public SalaryManage()
        {
            InitializeComponent();
        }

       
        public void DataDisplay(string sqlSelect)
        {
            
            salaryGridview.DataSource = Sqlserver.DataShow(sqlSelect).Tables["Employee"];                
        }


        //显示全部员工信息

        private void searchSalary_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select employeeId 员工编号,employeeName 员工姓名,employeeSalary 薪资 from Employee  where 1=1";
            string text = textId.Text.Trim();
            sqlSelect += "and employeeId=" + text;
            DataDisplay(sqlSelect);
        }
        //工资查询，选择不同的标准
        private void salaryQuery_Click(object sender, EventArgs e)
        {
            string sqlSelect = "select employeeId 员工编号,employeeName 员工姓名,employeeSalary 薪资 from Employee  ";
            string text = salaryCombox.Text;
            if (text.Equals("全部信息"))
            {
                string sqlSelectAll = "select employeeId 员工编号,employeeName 员工姓名,employeeSalary 薪资 from Employee ";
                DataDisplay(sqlSelectAll);
            }
            else if (text == "从高到低")
            {
                sqlSelect += "order by employeeSalary desc";
                DataDisplay(sqlSelect);
            }
            else if (text == "从低到高")
            {
                sqlSelect += "order by employeeSalary";
                DataDisplay(sqlSelect);
            }
            else if (text == "最高工资")
            {
                sqlSelect += "where employeeSalary=(select max(employeeSalary) from Employee)";
                DataDisplay(sqlSelect);
            }
            else if (text == "最低工资")
            {
                sqlSelect += "where employeeSalary=(select min(employeeSalary) from Employee)";
                DataDisplay(sqlSelect);
            }
            else if (text == "部门平均工资和总工资")
            {
                string sqlSelect1 = "select  部门名称 ,AVG(薪资) 平均工资,sum(薪资)总工资 from perdep group by 部门名称";               
                DataDisplay(sqlSelect1);
            }
        }

        private void 返回ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Function function = new Function();
            this.Hide();
            function.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
