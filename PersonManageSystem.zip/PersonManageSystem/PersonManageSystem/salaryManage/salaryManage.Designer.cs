﻿namespace PersonManageSystem.salaryManage
{
    partial class SalaryManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalaryManage));
            this.salaryGridview = new System.Windows.Forms.DataGridView();
            this.employeeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.personManagementDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personManagementDataSet = new PersonManageSystem.PersonManagementDataSet();
            this.searchSalary = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textId = new System.Windows.Forms.TextBox();
            this.salaryCombox = new System.Windows.Forms.ComboBox();
            this.personManagementDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter = new PersonManageSystem.PersonManagementDataSetTableAdapters.EmployeeTableAdapter();
            this.salaryQuery = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.返回ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.salaryGridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // salaryGridview
            // 
            this.salaryGridview.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.salaryGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.salaryGridview.Location = new System.Drawing.Point(-4, 156);
            this.salaryGridview.Margin = new System.Windows.Forms.Padding(2);
            this.salaryGridview.Name = "salaryGridview";
            this.salaryGridview.RowHeadersWidth = 51;
            this.salaryGridview.RowTemplate.Height = 27;
            this.salaryGridview.Size = new System.Drawing.Size(361, 186);
            this.salaryGridview.TabIndex = 0;
            // 
            // employeeBindingSource1
            // 
            this.employeeBindingSource1.DataMember = "Employee";
            this.employeeBindingSource1.DataSource = this.personManagementDataSetBindingSource;
            // 
            // personManagementDataSetBindingSource
            // 
            this.personManagementDataSetBindingSource.DataSource = this.personManagementDataSet;
            this.personManagementDataSetBindingSource.Position = 0;
            // 
            // personManagementDataSet
            // 
            this.personManagementDataSet.DataSetName = "PersonManagementDataSet";
            this.personManagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // searchSalary
            // 
            this.searchSalary.BackColor = System.Drawing.Color.Transparent;
            this.searchSalary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchSalary.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.searchSalary.Location = new System.Drawing.Point(237, 28);
            this.searchSalary.Margin = new System.Windows.Forms.Padding(2);
            this.searchSalary.Name = "searchSalary";
            this.searchSalary.Size = new System.Drawing.Size(56, 21);
            this.searchSalary.TabIndex = 1;
            this.searchSalary.Text = "搜索";
            this.searchSalary.UseVisualStyleBackColor = false;
            this.searchSalary.Click += new System.EventHandler(this.searchSalary_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("华文新魏", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(84, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "工号：";
            // 
            // textId
            // 
            this.textId.Location = new System.Drawing.Point(131, 28);
            this.textId.Margin = new System.Windows.Forms.Padding(2);
            this.textId.Name = "textId";
            this.textId.Size = new System.Drawing.Size(92, 21);
            this.textId.TabIndex = 3;
            // 
            // salaryCombox
            // 
            this.salaryCombox.FormattingEnabled = true;
            this.salaryCombox.Items.AddRange(new object[] {
            "全部信息",
            "从高到低",
            "从低到高",
            "最高工资",
            "最低工资",
            "部门平均工资和总工资"});
            this.salaryCombox.Location = new System.Drawing.Point(191, 113);
            this.salaryCombox.Margin = new System.Windows.Forms.Padding(2);
            this.salaryCombox.Name = "salaryCombox";
            this.salaryCombox.Size = new System.Drawing.Size(88, 20);
            this.salaryCombox.TabIndex = 4;
            // 
            // personManagementDataSetBindingSource1
            // 
            this.personManagementDataSetBindingSource1.DataSource = this.personManagementDataSet;
            this.personManagementDataSetBindingSource1.Position = 0;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.personManagementDataSetBindingSource;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // salaryQuery
            // 
            this.salaryQuery.BackColor = System.Drawing.Color.Transparent;
            this.salaryQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.salaryQuery.Font = new System.Drawing.Font("华文新魏", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.salaryQuery.Location = new System.Drawing.Point(302, 113);
            this.salaryQuery.Margin = new System.Windows.Forms.Padding(2);
            this.salaryQuery.Name = "salaryQuery";
            this.salaryQuery.Size = new System.Drawing.Size(44, 21);
            this.salaryQuery.TabIndex = 5;
            this.salaryQuery.Text = "查询";
            this.salaryQuery.UseVisualStyleBackColor = false;
            this.salaryQuery.Click += new System.EventHandler(this.salaryQuery_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(357, 25);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.返回ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.系统ToolStripMenuItem.Text = "系统";
            // 
            // 返回ToolStripMenuItem
            // 
            this.返回ToolStripMenuItem.Name = "返回ToolStripMenuItem";
            this.返回ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.返回ToolStripMenuItem.Text = "返回";
            this.返回ToolStripMenuItem.Click += new System.EventHandler(this.返回ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // SalaryManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(357, 343);
            this.Controls.Add(this.salaryQuery);
            this.Controls.Add(this.salaryCombox);
            this.Controls.Add(this.textId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchSalary);
            this.Controls.Add(this.salaryGridview);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "SalaryManage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "薪资管理";
            ((System.ComponentModel.ISupportInitialize)(this.salaryGridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personManagementDataSetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView salaryGridview;
        private System.Windows.Forms.BindingSource personManagementDataSetBindingSource;
        private PersonManagementDataSet personManagementDataSet;
        private System.Windows.Forms.Button searchSalary;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textId;
        private System.Windows.Forms.ComboBox salaryCombox;
        private System.Windows.Forms.BindingSource personManagementDataSetBindingSource1;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private PersonManagementDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.BindingSource employeeBindingSource1;
        private System.Windows.Forms.Button salaryQuery;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 返回ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
    }
}